package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.AbsenceBeans;
import model.AbsenceModel;

@WebServlet("/absence_insert")
public class InsertAbsenceResistServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{

		////////////////////////////////////
		//セッションから値を取得
		HttpSession session = request.getSession();
		AbsenceBeans absenceBeans = (AbsenceBeans)session.getAttribute("absenceBeans");

		////////////////////////////////////
		//登録処理
		AbsenceModel absenceModel = new AbsenceModel();

		absenceModel.insert(absenceBeans);

		////////////////////////////////////
		//セッション情報を削除
		session.removeAttribute("absenceBeans");

		////////////////////////////////////
		//完了画面へリダイレクト
		response.sendRedirect("absence_complete");
	}
}
