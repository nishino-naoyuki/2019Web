package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.LoginInfoBeans;
import model.UserModel;

@WebServlet("/auth")
public class AuthServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{

		String userId = request.getParameter("userId");
		String pass = request.getParameter("pass");

		/////////////////////////////
		// モデル
		UserModel loginModel = new UserModel();
		LoginInfoBeans loginInfo = loginModel.login(userId, pass);

		// 結果
		if(loginInfo != null)
		{
			// セッションに保存
			HttpSession  session = request.getSession(true);
			session.setAttribute("loginInfo", loginInfo);
			response.sendRedirect("menu");
		} else
		{
			// エラーのとき
			request.setAttribute("errMsg", "メールアドレスかパスワードが違います");
			RequestDispatcher dispatcher =
					request.getRequestDispatcher("WEB-INF/jsp/login.jsp");
			dispatcher.forward(request, response);
		}


	}
}
