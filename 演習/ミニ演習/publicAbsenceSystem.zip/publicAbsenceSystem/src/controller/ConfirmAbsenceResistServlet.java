package controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.AbsenceBeans;
import beans.LoginInfoBeans;

@WebServlet("/absence_confirm")
public class ConfirmAbsenceResistServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		/////////////////////////
		//値の取得
		String dateString = request.getParameter("date");
		String companyName = request.getParameter("companyName");
		String reason = request.getParameter("reason");

		/////////////////////////
		//ビーンズに値をセットする
		AbsenceBeans absenceBeans = new AbsenceBeans();

		absenceBeans.setCompanyName(companyName);
		absenceBeans.setReason(reason);
		//文字列→日付の変換
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse(dateString);
			absenceBeans.setAbsenceDate(date);
		}catch(ParseException e){
			//日付に変換できないときはとりあえず、今日の日付を格納しておく
			absenceBeans.setAbsenceDate(new Date());
		}

		//ユーザーIDを取得するためセッションから
		//ログイン情報を取得する
		HttpSession session = request.getSession();
		LoginInfoBeans loginInfoBeans = (LoginInfoBeans)session.getAttribute("loginInfo");
		//ビーンズにuserId（学籍番号）をセット
		absenceBeans.setUserId( loginInfoBeans.getUserId() );

		/////////////////////////
		//セッションに保存（本来は保存の前に入力チェックをする）
		session.setAttribute("absenceBeans", absenceBeans);

		//////////////////////////
		//画面遷移
		RequestDispatcher dispatcher =
				request.getRequestDispatcher("WEB-INF/jsp/confirmAbsence.jsp");
		dispatcher.forward(request, response);
	}
}
