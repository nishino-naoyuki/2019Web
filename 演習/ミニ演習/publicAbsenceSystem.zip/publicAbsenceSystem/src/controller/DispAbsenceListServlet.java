package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.AbsenceBeans;
import beans.LoginInfoBeans;
import model.AbsenceModel;

@WebServlet("/absence_list")
public class DispAbsenceListServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		/////////////////////////////////////
		//セッションから学籍番号を取得
		HttpSession session = request.getSession();

		LoginInfoBeans loginInfo = (LoginInfoBeans)session.getAttribute("loginInfo");

		String userId  = loginInfo.getUserId();

		//////////////////////////////////////
		//一覧の取得
		AbsenceModel absenceModel = new AbsenceModel();

		List<AbsenceBeans> absenceList = absenceModel.getList(userId);

		//////////////////////////////////////
		//リクエストに一覧を保存する
		request.setAttribute("absenceList", absenceList);

		//////////////////////////////////////
		//画面遷移
		RequestDispatcher dispatcher =
				request.getRequestDispatcher("WEB-INF/jsp/dispAbsenceList.jsp");
		dispatcher.forward(request, response);
	}
}
