package model;

import beans.LoginInfoBeans;
import dao.UserDao;

/**
 * ユーザー情報のモデル
 *
 * @author nishino
 *
 */
public class UserModel {

	/**
	 * ログイン処理
	 *
	 * @param userId
	 * @param password
	 * @return null以外：ログイン成功　null：ログイン失敗
	 */
	public LoginInfoBeans login(String userId,String password){
		LoginInfoBeans userBeans = null;

		UserDao userDao = new UserDao();

		try{
			//接続
			userDao.connect();

			//値を検索
			userBeans = userDao.getBy(userId, password);
		}finally{
			userDao.close();
		}

		return userBeans;
	}
}
