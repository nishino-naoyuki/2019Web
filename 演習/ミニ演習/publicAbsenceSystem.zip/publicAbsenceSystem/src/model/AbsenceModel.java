package model;

import java.util.List;

import beans.AbsenceBeans;
import dao.AbsenceDao;

/**
 * 公欠届のモデル
 *
 * @author nishino
 *
 */
public class AbsenceModel {


	/**
	 * 公欠届の一覧を取得する（全権取得）
	 *
	 * @return
	 */
	public List<AbsenceBeans> getList(String studentId){
		List<AbsenceBeans> list = null;

		AbsenceDao absenceDao = new AbsenceDao();

		try{
			//DB接続
			absenceDao.connect();

			//一覧を取得
			list = absenceDao.getList(studentId);
		}finally{
			//DB切断
			absenceDao.close();
		}

		return list;
	}


	/**
	 * 公欠届の新規挿入
	 *
	 * @param absenceBeans
	 */
	public void insert(AbsenceBeans absenceBeans){

		AbsenceDao absenceDao = new AbsenceDao();

		try{
			//DB接続
			absenceDao.connect();

			//情報を挿入する
			absenceDao.insert(absenceBeans);
		}finally{
			//DB切断
			absenceDao.close();
		}
	}

}
