package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import beans.LoginInfoBeans;

/**
 * ユーザーテーブルのDAO
 *
 *
 * @author nishino
 *
 */
public class UserDao extends DaoBase {

	/**
	 * 指定した情報で検索をして
	 * ユーザー情報をDBより取得する
	 *
	 * @param mail
	 * @param password
	 * @return
	 */
	public LoginInfoBeans getBy(String mail,String password){
		LoginInfoBeans loginInfo = null;

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM students WHERE student_id=? and student_password=?");

			stmt.setString(1, mail);
			stmt.setString(2, password);
			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				loginInfo = new LoginInfoBeans();

				loginInfo.setUserId(rs.getString("student_id"));
				loginInfo.setUserName(rs.getString("student_name"));
			}

        } catch(SQLException e) {
            e.printStackTrace();
        }

		return loginInfo;
	}
}
