package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.AbsenceBeans;

/**
 * 公欠届テーブルのDAO
 *
 * @author nishino
 *
 */
public class AbsenceDao extends DaoBase {

	/**
	 * 公欠届の一覧を取得する（ユーザーを取得しユーザーごとの一覧を取得）
	 *
	 * @return
	 */
	public List<AbsenceBeans> getList(String studentId){
		List<AbsenceBeans> list = new ArrayList<AbsenceBeans>();

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM absences WHERE student_id=?");

			stmt.setString(1, studentId);
			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				AbsenceBeans absendBeans = new AbsenceBeans();

				absendBeans.setUserId(studentId);
				absendBeans.setAbsenceDate(rs.getDate("absence_date"));
				absendBeans.setCompanyName(rs.getString("company_name"));
				absendBeans.setReason(rs.getString("reason"));

				list.add(absendBeans);
			}

        } catch(SQLException e) {
            e.printStackTrace();
        }

		return list;
	}


	/**
	 * 公欠届の新規挿入
	 *
	 * @param absenceBeans
	 */
	public void insert(AbsenceBeans absenceBeans){

		if( con == null ) {
			return;
		}

		PreparedStatement stmt = null;

		try{
			///////////////////////////////////
			//INSERTT文の発行
			stmt = con.prepareStatement("INSERT INTO  absences(student_id,absence_date,company_name,reason) VALUES(?,?,?,?)");

			stmt.setString(1, absenceBeans.getUserId());
			stmt.setDate(2, new java.sql.Date( absenceBeans.getAbsenceDate().getTime()) );
			stmt.setString(3, absenceBeans.getCompanyName());
			stmt.setString(4, absenceBeans.getReason());

			stmt.executeUpdate();

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
	}
}
