package beans;

import java.util.Date;

/**
 * 公欠届情報
 *
 * @author nishino
 *
 */
public class AbsenceBeans {
	private String userId;
	private Date absenceDate;
	private String companyName;
	private String reason;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getAbsenceDate() {
		return absenceDate;
	}
	public void setAbsenceDate(Date absenceDate) {
		this.absenceDate = absenceDate;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}

}
