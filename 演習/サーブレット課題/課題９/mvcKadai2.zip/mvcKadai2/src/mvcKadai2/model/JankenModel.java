package mvcKadai2.model;

import java.util.Random;

import mvcKadai2.beans.JankenBean;

public class JankenModel {

	private static final int JANKEN_GU = 0;
	private static final int JANKEN_CHOKI = 1;
	private static final int JANKEN_PA = 2;

	private static final int JANKEN_WIN = 0;
	private static final int JANKEN_LOSE = 1;
	private static final int JANKEN_DRAW = 2;

	/**
	 * じゃんけんを実行する
	 *
	 * @param jankenSelect
	 * @return
	 */
	public JankenBean execute(int jankenSelect){

		///////////////////////////////////
		//コンピュータの手をランダムで決定する
		Random rand = new Random();

		int val = rand.nextInt(3);

		///////////////////////////////////
		//結果を取得
		int result = getGameResult(val,jankenSelect);

		///////////////////////////////////
		//メッセージを取得
		String message = getMessage(result);

		///////////////////////////////////
		//ビーンにセットする
		JankenBean jankenBean = new JankenBean();

		jankenBean.setMyFileName(getImgFileName(jankenSelect));
		jankenBean.setEnemyFileName(getImgFileName(val));
		jankenBean.setMessage(message);
		jankenBean.setResult(result);

		return jankenBean;
	}

	/**
	 * @param val
	 * @param jankenSelect
	 * @return
	 */
	private int getGameResult(int val,int jankenSelect){

		if( val == jankenSelect ){
			//引き分け！
			return JANKEN_DRAW;
		}

		int result = JANKEN_LOSE;

		//勝ちのパターン
		if( val == JANKEN_GU &&
				jankenSelect == JANKEN_PA){
			result = JANKEN_WIN;
		}else if( val == JANKEN_CHOKI &&
				jankenSelect == JANKEN_GU){
			result = JANKEN_WIN;
		}else if( val == JANKEN_PA &&
				jankenSelect == JANKEN_CHOKI){
			result = JANKEN_WIN;
		}

		return result;
	}

	/**
	 * @param result
	 * @return
	 */
	private String getMessage(int result){

		String message = "";

		if( result == JANKEN_WIN ){
			message = "勝ち！";
		}else if( result == JANKEN_LOSE ){
			message = "負け！";
		}else{
			message = "引き分け！";
		}

		return message;
	}

	/**
	 * @param select
	 * @return
	 */
	private String getImgFileName(int select){
		String fileName = "";

		if( select == JANKEN_GU){
			fileName = "janken_gu.png";
		}else if(select == JANKEN_CHOKI ){
			fileName = "janken_choki.png";
		}else{
			fileName = "janken_pa.png";
		}

		return fileName;
	}
}
