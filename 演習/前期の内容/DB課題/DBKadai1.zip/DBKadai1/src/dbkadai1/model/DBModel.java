package dbkadai1.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DBModel {
	public List<String> getMailList(){
		List<String> list = new ArrayList<String>();

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try{
			///////////////////////////////////
			//DBの接続
			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/webtestdb?characterEncoding=UTF-8&serverTimezone=JST",
					"root","");

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl");
			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				String value = rs.getString("name");
				list.add(value);
			}

		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}
}
