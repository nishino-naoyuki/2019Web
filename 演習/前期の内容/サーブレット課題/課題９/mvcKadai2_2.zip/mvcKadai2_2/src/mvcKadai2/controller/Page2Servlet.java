package mvcKadai2.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvcKadai2.beans.JankenBean;
import mvcKadai2.beans.ResultBean;
import mvcKadai2.model.JankenModel;

@WebServlet("/page2")
public class Page2Servlet extends HttpServlet {

	private static final int JANKEN_WIN = 0;
	private static final int JANKEN_LOSE = 1;
	private static final int JANKEN_DRAW = 2;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
											throws ServletException, IOException {

		////////////////////////////////
		//どれを選択したかを取得
		String janken = request.getParameter("janken");

		int jankenSelect = Integer.parseInt(janken);

		////////////////////////////////
		//じゃんけんの処理を行う
		JankenModel model = new JankenModel();

		JankenBean jankenBean = model.execute(jankenSelect);

		////////////////////////////////
		//結果をセット
		request.setAttribute("jankenBean", jankenBean);
		//勝敗の結果をセットする
		setResultToSession(request,jankenBean.getResult());

		////////////////////////////////
		//転送
		RequestDispatcher dispatcher =
				request.getRequestDispatcher("WEB-INF/jsp/page2.jsp");
		dispatcher.forward(request, response);
	}


	private void setResultToSession(HttpServletRequest request,int result){

		HttpSession session = request.getSession(true);
		ResultBean resultBean = (ResultBean)session.getAttribute("resultBean");

		if( resultBean == null ){
			resultBean = new ResultBean(0,0,0);
		}

		if(result == JANKEN_WIN){
			resultBean.incrementWin();
		}else if(result == JANKEN_LOSE){
			resultBean.incrementLose();
		}else{
			resultBean.incrementDraw();
		}

		session.setAttribute("resultBean", resultBean);
	}
}

