package mvcKadai2.beans;

public class ResultBean {

	private Integer win;
	private Integer lose;
	private Integer draw;

	public ResultBean() {
		this.win = 0;
		this.lose = 0;
		this.draw = 0;
	}
	public ResultBean(int win,int lose,int draw) {
		this.win = win;
		this.lose = lose;
		this.draw = draw;
	}

	public void incrementWin(){
		win++;
	}
	public Integer getWin() {
		return win;
	}
	public void setWin(Integer win) {
		this.win = win;
	}
	public void incrementLose(){
		lose++;
	}
	public Integer getLose() {
		return lose;
	}
	public void setLose(Integer lose) {
		this.lose = lose;
	}
	public void incrementDraw(){
		draw++;
	}
	public Integer getDraw() {
		return draw;
	}
	public void setDraw(Integer draw) {
		this.draw = draw;
	}


}
