package mvcKadai2.beans;

import java.io.Serializable;

public class JankenBean implements Serializable{
	private String myFileName;
	private String enemyFileName;
	private String message;
	private Integer result;
	/**
	 * @return myFileName
	 */
	public String getMyFileName() {
		return myFileName;
	}
	/**
	 * @param myFileName セットする myFileName
	 */
	public void setMyFileName(String myFileName) {
		this.myFileName = myFileName;
	}
	/**
	 * @return enemyFileName
	 */
	public String getEnemyFileName() {
		return enemyFileName;
	}
	/**
	 * @param enemyFileName セットする enemyFileName
	 */
	public void setEnemyFileName(String enemyFileName) {
		this.enemyFileName = enemyFileName;
	}
	/**
	 * @return message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message セットする message
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return result
	 */
	public Integer getResult() {
		return result;
	}
	/**
	 * @param result セットする result
	 */
	public void setResult(Integer result) {
		this.result = result;
	}



}
