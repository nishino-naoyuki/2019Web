package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.UserModel;

@WebServlet("/update")
public class UpdateBmiServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//////////////////////////////
		//JSPからの値取得
		String mail = request.getParameter("mail");
		String weightStr = request.getParameter("weight");
		String tallStr = request.getParameter("tall");

		UserModel userMoldel = new UserModel();

		//////////////////////////////
		//文字列→数値変換
		int weight = 0;
		int tall = 0;

		try {
			weight = Integer.parseInt(weightStr);
			tall = Integer.parseInt(tallStr);
		}catch(Exception e) {
			request.setAttribute("error", "体重と身長に数値以外が入力されました");
			RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/complete.jsp");
			dispatcher.forward(request, response);
			return;
		}

		//////////////////////////////
		// 身長と体重、BMIを登録する
		userMoldel.updateBmiInfo(mail, tall, weight);

		//////////////////////////////
		//画面遷移
		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/complete.jsp");
		dispatcher.forward(request, response);
	}
}
