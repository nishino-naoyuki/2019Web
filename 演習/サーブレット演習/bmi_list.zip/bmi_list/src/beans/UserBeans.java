package beans;

public class UserBeans {
	private String name;	//名前
	private String mail;	//メールアドレス
	private int tall;		//身長
	private int weight;	//体重
	private double bmi;	//BMI
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name セットする name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return mail
	 */
	public String getMail() {
		return mail;
	}
	/**
	 * @param mail セットする mail
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}
	/**
	 * @return tall
	 */
	public int getTall() {
		return tall;
	}
	/**
	 * @param tall セットする tall
	 */
	public void setTall(int tall) {
		this.tall = tall;
	}
	/**
	 * @return weight
	 */
	public int getWeight() {
		return weight;
	}
	/**
	 * @param weight セットする weight
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}
	/**
	 * @return bmi
	 */
	public double getBmi() {
		return bmi;
	}
	/**
	 * @param bmi セットする bmi
	 */
	public void setBmi(double bmi) {
		this.bmi = bmi;
	}




}
