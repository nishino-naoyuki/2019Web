package model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.UserBeans;

public class UserDao extends DaoBase{

	/**
	 * ユーザー情報の更新
	 *
	 * @param userBeans 更新対象のユーザー情報
	 *
	 */
	public void update(UserBeans userBeans) {
		if( con == null ){
			return;
		}

		PreparedStatement stmt = null;

		try{
			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("UPDATE  user_tbl SET tall=?,weight=?,bmi=? WHERE mail=?");

			stmt.setInt(1, userBeans.getTall());
			stmt.setInt(2, userBeans.getWeight());
			stmt.setDouble(3, userBeans.getBmi());
			stmt.setString(4, userBeans.getMail());
			stmt.executeUpdate();

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}

	}

	/**
	 * メールアドレスを指定してユーザー情報を取得する
	 *
	 * @param mail　ユーザー情報
	 * @return
	 */
	public UserBeans getBy(String mail) {
		if( con == null ){
			return null;
		}

		PreparedStatement stmt = null;
		ResultSet rs = null;
		UserBeans userBeans = new UserBeans();


		try{
			stmt = con.prepareStatement("SELECT * FROM user_tbl WHERE mail=? ");

			stmt.setString(1, mail);
			rs = stmt.executeQuery();

			while( rs.next() ) {
				userBeans.setBmi(rs.getDouble("bmi"));
				userBeans.setMail(rs.getString("mail"));
				userBeans.setName(rs.getString("name"));
				userBeans.setTall(rs.getInt("tall"));
				userBeans.setWeight(rs.getInt("weight"));
			}

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}

		return userBeans;
	}

	/**
	 * ユーザー情報のリストを取得する
	 *
	 * @return
	 */
	public List<UserBeans> getList(){
		if( con == null ){
			return null;
		}

		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<UserBeans> list = new ArrayList<UserBeans>();


		try{
			stmt = con.prepareStatement("SELECT * FROM user_tbl");

			rs = stmt.executeQuery();

			while( rs.next() ) {
				UserBeans userBeans = new UserBeans();

				userBeans.setBmi(rs.getDouble("bmi"));
				userBeans.setMail(rs.getString("mail"));
				userBeans.setName(rs.getString("name"));
				userBeans.setTall(rs.getInt("tall"));
				userBeans.setWeight(rs.getInt("weight"));

				list.add(userBeans);
			}

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}

		return list;

	}
}
