package model;

import java.util.List;

import beans.UserBeans;
import model.dao.UserDao;

public class UserModel {

	/**
	 * 身長体重BMIを更新する
	 *
	 * @param userBeans
	 */
	public void updateBmiInfo(String mail,int tall,int weight) {

		// BMI ＝ 体重kg ÷ (身長m)2
		double bmi = (double)weight/((double)((tall/100.0)*(tall/100.0)));

		//ユーザー情報を取得する
		UserDao userDao = new UserDao();

		try {
			//接続
			userDao.connect();

			//現状のユーザー情報を取得する
			UserBeans userBeans = userDao.getBy(mail);

			//更新する値をBeansに詰める
			userBeans.setBmi(bmi);
			userBeans.setTall(tall);
			userBeans.setWeight(weight);

			//更新処理
			userDao.update(userBeans);
		}catch(Exception e) {

			e.printStackTrace();
		}finally {
			userDao.close();
		}
	}

	/**
	 * ユーザー一覧の取得
	 *
	 * @return
	 */
	public List<UserBeans> getList(){
		List<UserBeans> list = null;

		//ユーザー情報を取得する
		UserDao userDao = new UserDao();

		try {
			//接続
			userDao.connect();

			//ユーザー一覧を取得する
			list = userDao.getList();

		}catch(Exception e) {

			e.printStackTrace();
		}finally {
			userDao.close();
		}

		return list;
	}
}
