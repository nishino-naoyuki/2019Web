package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import beans.UserBeans;

/**
 *
 * @author nishino
 *
 */
public class UserModel {

	/**
	 * ユーザーリストの取得を行う
	 *
	 * @return ユーザーのList
	 */
	public List<UserBeans> getUserList(){
		List<UserBeans> userList = new ArrayList<UserBeans>();

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		InitialContext context = null;

		try{
			///////////////////////////////////
			//DBの接続
			String jndi = "java:comp/env/jdbc/MySQL";

			context = new InitialContext();

			DataSource dataSource = (DataSource) context.lookup(jndi);

			con = dataSource.getConnection();


			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl");

			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				UserBeans userBeans = new UserBeans();

				userBeans.setMail(rs.getString("mail"));
				userBeans.setName(rs.getString("name"));

				userList.add(userBeans);
			}

		}catch(NamingException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return userList;
	}
}
