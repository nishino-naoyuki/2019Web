package model;

import java.util.ArrayList;
import java.util.List;

import beans.LoginInfoBeans;
import beans.UserBeans;
import dao.UserDao;

/**
 * ユーザー情報のモデル
 *
 * @author nishino
 *
 */
public class UserModel {

	/**
	 * ユーザー情報の一覧を取得する
	 *
	 * @return
	 */
	public List<UserBeans> getList(){

		List<UserBeans> list = new ArrayList<UserBeans>();

		UserDao userDao = new UserDao();

		try{
			//接続
			userDao.connect();

			//値を検索
			list = userDao.getList();
		}finally{
			userDao.close();
		}

		return list;
	}

	/**
	 * ログイン処理
	 *
	 * @param mail
	 * @param password
	 * @return null以外：ログイン成功　null：ログイン失敗
	 */
	public LoginInfoBeans login(String mail,String password){
		LoginInfoBeans userBeans = null;

		UserDao userDao = new UserDao();

		try{
			//接続
			userDao.connect();

			//値を検索
			userBeans = userDao.getBy(mail, password);
		}finally{
			userDao.close();
		}

		return userBeans;
	}

	/**
	 * 引数のビーンズの値を登録する
	 * @param userBeans
	 */
	public void insert(UserBeans userBeans) {

		UserDao userDao = new UserDao();

		try{
			//接続
			userDao.connect();

			//登録処理
			userDao.insert(userBeans);
		}finally{
			userDao.close();
		}

	}
}
