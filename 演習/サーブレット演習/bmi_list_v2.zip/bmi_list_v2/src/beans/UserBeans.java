package beans;

/**
 * ユーザー情報のビーンズ
 *
 * @author nishino
 *
 */
public class UserBeans {

	private String name;
	private String mail;
	private String password;	//設定用

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password セットする password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
}
