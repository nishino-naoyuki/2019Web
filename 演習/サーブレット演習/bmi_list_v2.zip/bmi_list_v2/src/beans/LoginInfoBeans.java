package beans;

import java.io.Serializable;

/**
 *
 * ログイン情報（セッション保存用）
 *
 * @author nishino
 *
 */
public class LoginInfoBeans implements Serializable {

	private String mail;
	private String userName;

	/**
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName セットする userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return mail
	 */
	public String getMail() {
		return mail;
	}
	/**
	 * @param mail セットする mail
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}


}
