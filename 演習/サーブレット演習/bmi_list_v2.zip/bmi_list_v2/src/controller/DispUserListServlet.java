package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.UserBeans;
import model.UserModel;

@WebServlet("/userList")
public class DispUserListServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		//////////////////////////////////////
		//一覧の取得
		UserModel userModel = new UserModel();

		List<UserBeans> userList = userModel.getList();

		//////////////////////////////////////
		//リクエストに一覧を保存する
		request.setAttribute("userList", userList);

		//////////////////////////////////////
		//画面遷移
		RequestDispatcher dispatcher =
				request.getRequestDispatcher("WEB-INF/jsp/dispUserList.jsp");
		dispatcher.forward(request, response);
	}
}
