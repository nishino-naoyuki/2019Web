package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.UserBeans;

@WebServlet("/confirmuser")
public class ConfirmUserRegistServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		/////////////////////////
		//値の取得
		String mail = request.getParameter("mail");
		String password = request.getParameter("password");
		String name = request.getParameter("name");

		/////////////////////////
		//ビーンズに値をセットする
		UserBeans userBeans = new UserBeans();

		userBeans.setMail(mail);
		userBeans.setPassword(password);
		userBeans.setName(name);

		/////////////////////////
		//セッションに保存（本来は保存の前に入力チェックをする）
		HttpSession session = request.getSession();
		session.setAttribute("userBeans", userBeans);

		//////////////////////////
		//画面遷移
		RequestDispatcher dispatcher =
				request.getRequestDispatcher("WEB-INF/jsp/confirmUser.jsp");
		dispatcher.forward(request, response);
	}
}
