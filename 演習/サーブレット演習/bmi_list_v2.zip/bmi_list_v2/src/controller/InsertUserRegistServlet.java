package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.UserBeans;
import model.UserModel;

@WebServlet("/insertuser")
public class InsertUserRegistServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{

		////////////////////////////////////
		//セッションから値を取得
		HttpSession session = request.getSession();
		UserBeans userBeans = (UserBeans)session.getAttribute("userBeans");

		////////////////////////////////////
		//登録処理
		UserModel userModel = new UserModel();

		userModel.insert(userBeans);

		////////////////////////////////////
		//セッション情報を削除
		session.removeAttribute("userBeans");

		////////////////////////////////////
		//完了画面へリダイレクト
		response.sendRedirect("completeuser");
	}
}
