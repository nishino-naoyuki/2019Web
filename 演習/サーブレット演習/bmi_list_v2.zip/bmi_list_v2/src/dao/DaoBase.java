package dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * DAOのベースクラス
 *
 * DAOに共通な接続・切断のメソッドを持つ
 *
 * @author nishino
 *
 */
public class DaoBase {

	protected Connection con = null;


	public DaoBase(){
	}

	public DaoBase(Connection con){
		this.con = con;
	}

	public void connect() {

		if( con != null ){
			//接続済みの場合は何もしない
			return;
		}

    	InitialContext ctx;
		try {
			///////////////////////////////////
			//DBの接続
			String jndi = "java:comp/env/jdbc/MySQL";
			ctx = new InitialContext();

        	DataSource ds =
        		(DataSource)ctx.lookup(jndi);

			// MySQLに接続
	        con = ds.getConnection();

		} catch (NamingException e) {
			e.printStackTrace();
			//本当は例外をスローして上位側に処理を任せた方がよい
		} catch (SQLException e) {
			e.printStackTrace();
			//本当は例外をスローして上位側に処理を任せた方がよい
		}


	}

	public void close(){

		if( con != null ){
			try {
				con.close();
				con = null;
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Connection getConnection(){
		return con;
	}
}
