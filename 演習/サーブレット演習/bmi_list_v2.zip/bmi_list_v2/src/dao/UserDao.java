package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.LoginInfoBeans;
import beans.UserBeans;

/**
 * ユーザーテーブルのDAO
 *
 *
 * @author nishino
 *
 */
public class UserDao extends DaoBase {


	/**
	 * ユーザーの一覧情報を取得する
	 *
	 * @return
	 */
	public List<UserBeans> getList(){

		if( con == null ) {
			return null;
		}
		List<UserBeans> list = new ArrayList<UserBeans>();

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl");

			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				UserBeans userBeans = new UserBeans();

				userBeans.setMail(rs.getString("mail"));
				userBeans.setName(rs.getString("name"));

				list.add(userBeans);
			}

        } catch(SQLException e) {
            e.printStackTrace();
        }
		return list;
	}
	/**
	 * ユーザー情報を登録する
	 *
	 * @param userBeans
	 */
	public void insert(UserBeans userBeans) {
		if( con == null ) {
			return;
		}


		PreparedStatement stmt = null;

		try{
			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("INSERT INTO  user_tbl(mail,password,name) VALUES(?,?,?)");

			stmt.setString(1, userBeans.getMail());
			stmt.setString(2, userBeans.getPassword());
			stmt.setString(3, userBeans.getName());

			stmt.executeUpdate();

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
	}

	/**
	 * 指定した情報で検索をして
	 * ユーザー情報をDBより取得する
	 *
	 * @param mail
	 * @param password
	 * @return
	 */
	public LoginInfoBeans getBy(String mail,String password){
		if( con == null ) {
			return null;
		}
		LoginInfoBeans loginInfo = null;

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl WHERE mail=? and password=?");

			stmt.setString(1, mail);
			stmt.setString(2, password);
			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				loginInfo = new LoginInfoBeans();

				loginInfo.setMail(rs.getString("mail"));
				loginInfo.setUserName(rs.getString("name"));
			}

        } catch(SQLException e) {
            e.printStackTrace();
        }
		return loginInfo;
	}
}
